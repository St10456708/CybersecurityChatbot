﻿using System.Media;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Core chatbot controller class.
    /// Orchestrates startup sequence, voice greeting, user interaction loop,
    /// input validation, personalised responses, and graceful exit.
    /// </summary>
    public class ChatBot
    {
        // ── Fields ────────────────────────────────────────────────────────────
        private string _userName = "User";

        private readonly string[] _securityTips = new[]
        {
            "Always use unique, strong passwords for every account you own!",
            "Enable Two-Factor Authentication (2FA) on all important accounts.",
            "Think before you click — phishing links look legitimate at first glance.",
            "Keep your operating system and apps updated to patch security vulnerabilities.",
            "Back up your data regularly to both a local drive and cloud storage.",
            "Never share your passwords, PINs, or OTPs — even with IT support staff.",
            "Use a VPN on public Wi-Fi to encrypt your internet connection.",
            "Check haveibeenpwned.com to see if your email appeared in a data breach.",
        };

        // ── Public Entry Point ─────────────────────────────────────────────────

        /// <summary>
        /// Main entry point for the chatbot.
        /// Runs the full startup sequence and then enters the chat loop.
        /// </summary>
        public void Run()
        {
            // Enable UTF-8 so special characters and emoji display correctly
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.Title = "Cybersecurity Awareness Bot v1.0";

            DisplayLaunchSequence();
            PlayVoiceGreeting();
            GreetAndGetName();
            DisplayWelcomeMessage();
            ChatLoop();
        }

        // ── Private Methods ────────────────────────────────────────────────────

        /// <summary>
        /// Displays the ASCII art logo and title screen on launch.
        /// </summary>
        private void DisplayLaunchSequence()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(AsciiArt.Logo);
            Console.ResetColor();

            Thread.Sleep(500);

            ConsoleUI.PrintColoured("  Initialising Cybersecurity Awareness Bot...", ConsoleColor.DarkGray);
            Thread.Sleep(300);
            ConsoleUI.PrintColoured("  Loading response database...           ✅", ConsoleColor.DarkGreen);
            Thread.Sleep(300);
            ConsoleUI.PrintColoured("  Setting up secure console environment...✅", ConsoleColor.DarkGreen);
            Thread.Sleep(300);
            ConsoleUI.PrintColoured("  Ready.\n", ConsoleColor.DarkGreen);
            Thread.Sleep(400);
        }

        /// <summary>
        /// Attempts to play the WAV voice greeting file.
        /// Fails gracefully with a console notice if the file is missing.
        /// </summary>
        private void PlayVoiceGreeting()
        {
            string wavPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");

            if (File.Exists(wavPath))
            {
                try
                {
                    ConsoleUI.PrintColoured(
                        "  🔊 Playing voice greeting...", ConsoleColor.DarkCyan);

                    using SoundPlayer player = new SoundPlayer(wavPath);
                    player.PlaySync(); // plays fully before continuing
                }
                catch (Exception ex)
                {
                    // Non-fatal: chatbot continues even if audio fails
                    ConsoleUI.PrintColoured(
                        $"  [Audio notice: {ex.Message}]", ConsoleColor.DarkGray);
                }
            }
            else
            {
                ConsoleUI.PrintColoured(
                    "  [Voice greeting: place 'greeting.wav' in the output folder to enable audio]",
                    ConsoleColor.DarkGray);
            }
        }

        /// <summary>
        /// Asks the user for their name and stores it for personalisation.
        /// Validates that the name is not empty.
        /// </summary>
        private void GreetAndGetName()
        {
            ConsoleUI.PrintHeader("WELCOME TO THE CYBERSECURITY AWARENESS BOT");

            ConsoleUI.PrintBotMessage(
                "Hello! I'm your Cybersecurity Awareness Bot — your personal digital guardian.");

            ConsoleUI.PrintBotMessage("Before we begin, what's your name?");

            string nameInput = string.Empty;

            // Input validation: keep asking until a valid name is provided
            while (string.IsNullOrWhiteSpace(nameInput))
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("  👤 Your name: ");
                Console.ResetColor();

                nameInput = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(nameInput))
                {
                    ConsoleUI.PrintError(
                        "I didn't catch your name. Please enter your name to continue.");
                }
            }

            _userName = nameInput.Trim();
        }

        /// <summary>
        /// Displays the personalised welcome message, topics menu, and a security tip.
        /// </summary>
        private void DisplayWelcomeMessage()
        {
            ConsoleUI.PrintBotMessage(
                $"Wonderful to meet you, {_userName}! 🛡️");

            ConsoleUI.PrintBotMessage(
                $"I'm here to help you navigate cybersecurity threats and stay safe online, {_userName}.");

            ConsoleUI.PrintTopicsMenu();

            // Display a random security tip to engage the user immediately
            Random rng = new Random();
            string tip = _securityTips[rng.Next(_securityTips.Length)];
            ConsoleUI.PrintTip(tip);
        }

        /// <summary>
        /// Main conversation loop. Handles all user input, validation,
        /// response retrieval, and personalised output until the user exits.
        /// </summary>
        private void ChatLoop()
        {
            while (true)
            {
                ConsoleUI.PrintUserPrompt(_userName);
                string userInput = Console.ReadLine();

                // ── Input Validation: Empty input ───────────────────────────
                if (string.IsNullOrWhiteSpace(userInput))
                {
                    ConsoleUI.PrintError(
                        "I didn't quite catch that. Could you please rephrase your question?");
                    continue;
                }

                // ── Input Validation: Too short ─────────────────────────────
                if (userInput.Trim().Length < 2)
                {
                    ConsoleUI.PrintError(
                        "That seems too short! Please ask me a question or type a topic keyword.");
                    continue;
                }

                // ── Check for exit command ──────────────────────────────────
                if (Responses.IsExitCommand(userInput))
                {
                    string exitMsg = Responses.GetResponse(userInput, _userName);
                    ConsoleUI.PrintBotMessage(exitMsg);
                    ConsoleUI.PrintHeader($"GOODBYE, {_userName.ToUpper()}! STAY CYBER SAFE!");
                    Thread.Sleep(1500);
                    break;
                }

                // ── Show 'help' menu ────────────────────────────────────────
                if (userInput.Trim().ToLower() == "help")
                {
                    ConsoleUI.PrintTopicsMenu();
                    continue;
                }

                // ── Retrieve and display response ───────────────────────────
                string response = Responses.GetResponse(userInput, _userName);

                if (response == null)
                {
                    // Should not reach here (empty input caught above), but handles edge cases
                    ConsoleUI.PrintError(
                        "I didn't quite understand that. Could you rephrase?");
                }
                else if (response == "default")
                {
                    // Unsupported or unrecognised query — helpful fallback
                    ConsoleUI.PrintBotMessage(
                        $"Hmm, I'm not sure about that, {_userName}. " +
                        $"I specialise in cybersecurity topics.");
                    ConsoleUI.PrintBotMessage(
                        "Try typing: password, phishing, browsing, malware, 2fa, privacy, ransomware, or vpn.");
                    ConsoleUI.PrintBotMessage(
                        "Or type 'help' to see the full list of topics.");
                }
                else if (response.Contains('\n'))
                {
                    // Multi-line responses get special formatting
                    ConsoleUI.PrintBotMessageMultiLine(response);
                }
                else
                {
                    ConsoleUI.PrintBotMessage(response);
                }

                // Show a random tip occasionally (every ~4 messages)
                Random rng = new Random();
                if (rng.Next(4) == 0)
                {
                    string tip = _securityTips[rng.Next(_securityTips.Length)];
                    ConsoleUI.PrintTip(tip);
                }
            }
        }
    }
}
