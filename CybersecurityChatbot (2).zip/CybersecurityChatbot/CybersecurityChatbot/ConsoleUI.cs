﻿namespace CybersecurityChatbot
{
    /// <summary>
    /// Handles all console UI rendering including colours, borders,
    /// spacing, typing effects, and visual structure for readability.
    /// </summary>
    public static class ConsoleUI
    {
        private const int TypingDelayMs = 18;
        private const int LineWidth = 66;

        /// <summary>Prints text in the specified colour, then resets.</summary>
        public static void PrintColoured(string text, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(text);
            Console.ResetColor();
        }

        /// <summary>Simulates a typing effect — character by character output.</summary>
        public static void PrintWithTypingEffect(string text, ConsoleColor color, int delayMs = TypingDelayMs)
        {
            Console.ForegroundColor = color;
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delayMs);
            }
            Console.WriteLine();
            Console.ResetColor();
        }

        /// <summary>Prints a horizontal divider line.</summary>
        public static void PrintDivider(char symbol = '─', ConsoleColor color = ConsoleColor.DarkCyan)
        {
            PrintColoured("  " + new string(symbol, LineWidth), color);
        }

        /// <summary>Prints a double-line boxed section header.</summary>
        public static void PrintHeader(string title)
        {
            string padded = $"  {title}  ";
            int padding = Math.Max(0, LineWidth - padded.Length);
            string left = new string(' ', padding / 2);

            Console.WriteLine();
            PrintColoured("  ╔" + new string('═', LineWidth) + "╗", ConsoleColor.Cyan);
            PrintColoured($"  ║{left}{padded}{new string(' ', LineWidth - left.Length - padded.Length)}║", ConsoleColor.Cyan);
            PrintColoured("  ╚" + new string('═', LineWidth) + "╝", ConsoleColor.Cyan);
            Console.WriteLine();
        }

        /// <summary>Prints a bot message with icon, typing effect, and divider.</summary>
        public static void PrintBotMessage(string message)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("  🤖 CyberBot » ");
            Console.ResetColor();
            PrintWithTypingEffect(message, ConsoleColor.White);
            PrintDivider();
        }

        /// <summary>
        /// Prints a multi-line bot message, handling newline characters
        /// so each line is indented and formatted correctly.
        /// </summary>
        public static void PrintBotMessageMultiLine(string message)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("  🤖 CyberBot » ");
            Console.ResetColor();

            string[] lines = message.Split('\n');
            bool firstLine = true;
            foreach (string line in lines)
            {
                if (firstLine)
                {
                    PrintWithTypingEffect(line, ConsoleColor.White);
                    firstLine = false;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("                  " + line);
                    Console.ResetColor();
                    Thread.Sleep(80);
                }
            }
            PrintDivider();
        }

        /// <summary>Displays the prompt for user input with personalised name.</summary>
        public static void PrintUserPrompt(string userName)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"  👤 {userName} » ");
            Console.ResetColor();
        }

        /// <summary>Prints a red error/warning message with icon.</summary>
        public static void PrintError(string message)
        {
            Console.WriteLine();
            PrintColoured($"  ⚠️  Warning: {message}", ConsoleColor.Red);
            PrintDivider('─', ConsoleColor.DarkRed);
        }

        /// <summary>Prints a highlighted security tip in magenta.</summary>
        public static void PrintTip(string tip)
        {
            Console.WriteLine();
            PrintDivider('·', ConsoleColor.DarkMagenta);
            PrintColoured("  💡 SECURITY TIP OF THE DAY:", ConsoleColor.Magenta);
            PrintWithTypingEffect($"     {tip}", ConsoleColor.White, 12);
            PrintDivider('·', ConsoleColor.DarkMagenta);
        }

        /// <summary>Prints a topic menu showing available categories.</summary>
        public static void PrintTopicsMenu()
        {
            Console.WriteLine();
            PrintColoured("  ┌─────────────────────────────────────────┐", ConsoleColor.DarkCyan);
            PrintColoured("  │         TOPICS I CAN HELP WITH          │", ConsoleColor.Cyan);
            PrintColoured("  ├─────────────────────────────────────────┤", ConsoleColor.DarkCyan);
            PrintColoured("  │  🔑  Passwords & Password Safety         │", ConsoleColor.White);
            PrintColoured("  │  🎣  Phishing Attacks                    │", ConsoleColor.White);
            PrintColoured("  │  🌐  Safe Browsing                       │", ConsoleColor.White);
            PrintColoured("  │  🦠  Malware & Viruses                   │", ConsoleColor.White);
            PrintColoured("  │  🔐  Two-Factor Authentication (2FA)     │", ConsoleColor.White);
            PrintColoured("  │  🕵️  Privacy & Data Protection           │", ConsoleColor.White);
            PrintColoured("  │  🔥  Ransomware                          │", ConsoleColor.White);
            PrintColoured("  │  📶  VPN & Public Wi-Fi Safety           │", ConsoleColor.White);
            PrintColoured("  │  ❓  Type 'help' to see this menu again  │", ConsoleColor.DarkGray);
            PrintColoured("  │  🚪  Type 'exit' or 'bye' to quit        │", ConsoleColor.DarkGray);
            PrintColoured("  └─────────────────────────────────────────┘", ConsoleColor.DarkCyan);
            Console.WriteLine();
        }

        /// <summary>Clears the screen and shows a section break.</summary>
        public static void PrintSectionBreak()
        {
            Console.WriteLine();
            PrintDivider('═', ConsoleColor.DarkGray);
            Console.WriteLine();
        }
    }
}