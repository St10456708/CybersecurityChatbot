﻿namespace CybersecurityChatbot
{
    /// <summary>
    /// Provides ASCII art visuals for the Cybersecurity Awareness Bot.
    /// Displayed as a header/title screen when the chatbot launches.
    /// </summary>
    public static class AsciiArt
    {
        public static string Logo = @"
  ╔══════════════════════════════════════════════════════════════════╗
  ║                                                                  ║
  ║    ██████╗██╗   ██╗██████╗ ███████╗██████╗                      ║
  ║   ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗                     ║
  ║   ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝                     ║
  ║   ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗                     ║
  ║   ╚██████╗   ██║   ██████╔╝███████╗██║  ██║                     ║
  ║    ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝                    ║
  ║                                                                  ║
  ║    ██████╗  ██████╗ ████████╗                                    ║
  ║    ██╔══██╗██╔═══██╗╚══██╔══╝                                    ║
  ║    ██████╔╝██║   ██║   ██║                                       ║
  ║    ██╔══██╗██║   ██║   ██║                                       ║
  ║    ██████╔╝╚██████╔╝   ██║                                       ║
  ║    ╚═════╝  ╚═════╝    ╚═╝                                       ║
  ║                                                                  ║
  ║        🛡️  CYBERSECURITY AWARENESS BOT  v1.0  🛡️               ║
  ║        ──────────────────────────────────────────               ║
  ║          Your Intelligent Digital Shield Online                  ║
  ║                                                                  ║
  ╚══════════════════════════════════════════════════════════════════╝";

        public static string Shield = @"
            /\
           /  \
          / 🔒 \
         /______\
         |  C   |
         |  Y   |
         |  B   |
         |  E   |
         |  R   |
         \      /
          \    /
           \  /
            \/";
    }
}
