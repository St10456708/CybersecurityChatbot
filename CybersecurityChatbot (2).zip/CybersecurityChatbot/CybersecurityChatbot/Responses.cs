﻿namespace CybersecurityChatbot
{
    /// <summary>
    /// Manages all chatbot response logic.
    /// Handles exact matches, keyword matching, and default fallback responses.
    /// Covers a wide range of cybersecurity topics with depth and clarity.
    /// </summary>
    public static class Responses
    {
        /// <summary>
        /// Dictionary of keyword-to-response mappings.
        /// Covers greetings, cybersecurity topics, and exit commands.
        /// </summary>
        private static readonly Dictionary<string, string> ResponseMap =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // ── General Greetings ────────────────────────────────────────────
            { "hello",
                "Hello! Welcome to the Cybersecurity Awareness Bot. " +
                "I'm here to help you navigate the digital world safely. " +
                "What would you like to learn about today?" },

            { "hi",
                "Hi there! Great to see you taking your cybersecurity seriously. " +
                "Ask me anything — I'm here to help!" },

            { "hey",
                "Hey! Ready to boost your cybersecurity knowledge? " +
                "Type 'help' to see all the topics I can assist with." },

            { "how are you",
                "I'm operating at 100% security capacity — no breaches detected! " +
                "Thanks for asking. More importantly, how can I help keep YOU safe online today?" },

            { "what's your purpose",
                "My purpose is to raise cybersecurity awareness and empower you " +
                "with practical knowledge to stay safe online. I can help with topics like " +
                "passwords, phishing, safe browsing, malware, 2FA, and more." },

            { "what can i ask you about",
                "Great question! Here's what I specialise in:\n" +
                "  • Password safety & management\n" +
                "  • Recognising phishing attacks\n" +
                "  • Safe browsing habits\n" +
                "  • Malware and virus protection\n" +
                "  • Two-factor authentication (2FA)\n" +
                "  • Data privacy and protection\n" +
                "  • Ransomware awareness\n" +
                "  • VPN and public Wi-Fi safety\n" +
                "Type any of these topics to get started!" },

            { "who are you",
                "I'm the Cybersecurity Awareness Bot — your personal digital guardian! " +
                "I was built to help everyday users understand cybersecurity threats " +
                "and best practices to stay protected in the digital age." },

            { "help",
                "Of course! Here are all the topics I can assist you with.\n" +
                "Simply type a keyword or ask a full question:\n" +
                "  🔑 password | 🎣 phishing | 🌐 browsing\n" +
                "  🦠 malware | 🔐 2fa | 🕵️ privacy\n" +
                "  🔥 ransomware | 📶 vpn | 🏦 online banking" },

            // ── Password Safety ──────────────────────────────────────────────
            { "password",
                "Passwords are your first line of defence — make them count!\n" +
                "  ✅ Use at least 12–16 characters\n" +
                "  ✅ Mix UPPERCASE, lowercase, numbers (123), and symbols (!@#)\n" +
                "  ✅ Never reuse the same password across multiple sites\n" +
                "  ✅ Use a password manager like Bitwarden, LastPass, or 1Password\n" +
                "  ❌ Avoid: your name, birthdate, or the word 'password'\n" +
                "  ❌ Never share passwords via email, text, or chat" },

            { "password manager",
                "A password manager is software that securely stores all your passwords.\n" +
                "  • You only need to remember ONE master password\n" +
                "  • It generates strong, unique passwords for every site\n" +
                "  • Recommended options: Bitwarden (free), 1Password, Dashlane\n" +
                "  • Most managers also alert you if your passwords appear in data breaches" },

            // ── Phishing ─────────────────────────────────────────────────────
            { "phishing",
                "Phishing is a cyberattack where criminals trick you into revealing sensitive info!\n" +
                "  🚩 Red flags to watch for:\n" +
                "  • Urgent language: 'Act NOW or your account will be closed!'\n" +
                "  • Suspicious sender email addresses (e.g. support@paypa1.com)\n" +
                "  • Links that don't match the official website URL\n" +
                "  • Requests for passwords, PINs, or credit card numbers via email\n" +
                "  ✅ When in doubt — go directly to the website by typing it in your browser" },

            { "spear phishing",
                "Spear phishing is a targeted phishing attack aimed at a specific person.\n" +
                "  • Attackers research their victim beforehand (social media, LinkedIn)\n" +
                "  • Emails look highly convincing, often pretending to be your boss or bank\n" +
                "  • Always verify unexpected requests through a second channel (e.g. phone call)\n" +
                "  • Be especially cautious with emails asking you to transfer money or data" },

            // ── Safe Browsing ────────────────────────────────────────────────
            { "safe browsing",
                "Practising safe browsing protects you from countless online threats!\n" +
                "  ✅ Always check for 'https://' and a padlock icon in the address bar\n" +
                "  ✅ Keep your browser updated to patch security vulnerabilities\n" +
                "  ✅ Use reputable browser extensions like uBlock Origin for ad-blocking\n" +
                "  ✅ Avoid clicking pop-up warnings or 'You've won a prize!' messages\n" +
                "  ❌ Never download software from unofficial websites\n" +
                "  ❌ Avoid using public Wi-Fi for banking or entering sensitive information" },

            { "browsing",
                "Safe browsing is a habit that significantly reduces your risk online.\n" +
                "  • Look for HTTPS — the 'S' stands for Secure (data is encrypted)\n" +
                "  • Clear your browsing history and cookies regularly\n" +
                "  • Use private/incognito mode on shared or public computers\n" +
                "  • Be sceptical of websites with excessive pop-ups or ads" },

            // ── Malware ──────────────────────────────────────────────────────
            { "malware",
                "Malware is any software designed to harm, exploit, or compromise your system.\n" +
                "  Types of malware include:\n" +
                "  🦠 Viruses — spread by infecting files\n" +
                "  🐴 Trojans — disguised as legitimate software\n" +
                "  🔍 Spyware — secretly monitors your activity\n" +
                "  🔒 Ransomware — encrypts your files and demands payment\n" +
                "  ✅ Install reputable antivirus software and keep it updated\n" +
                "  ✅ Never open email attachments from unknown senders" },

            { "virus",
                "A computer virus is malicious code that replicates by attaching to files.\n" +
                "  • Viruses can corrupt files, steal data, or crash your system\n" +
                "  • They spread via email attachments, infected USB drives, and downloads\n" +
                "  ✅ Use updated antivirus software (e.g. Windows Defender, Malwarebytes)\n" +
                "  ✅ Scan all external drives before opening files\n" +
                "  ✅ Back up your data regularly to an external drive or cloud storage" },

            // ── Two-Factor Authentication ─────────────────────────────────────
            { "two-factor authentication",
                "Two-Factor Authentication (2FA) adds a critical second layer of security!\n" +
                "  How it works: even if someone steals your password, they still can't\n" +
                "  log in without the second factor (something only YOU have).\n" +
                "  ✅ Enable 2FA on: email, banking, social media, and shopping accounts\n" +
                "  ✅ Use an authenticator app (Google Authenticator, Microsoft Authenticator)\n" +
                "  ✅ Authenticator apps are safer than SMS-based codes\n" +
                "  ✅ Store your backup codes securely offline" },

            { "2fa",
                "2FA (Two-Factor Authentication) is one of the most effective security measures!\n" +
                "  • After entering your password, you confirm your identity a second way\n" +
                "  • Options: authenticator app, SMS code, email link, or hardware key\n" +
                "  • Hardware keys (like YubiKey) are the strongest form of 2FA\n" +
                "  • Even if hackers have your password, 2FA blocks unauthorised access" },

            // ── Privacy & Data Protection ─────────────────────────────────────
            { "privacy",
                "Protecting your digital privacy keeps your personal data out of the wrong hands.\n" +
                "  ✅ Read privacy policies before signing up for new services\n" +
                "  ✅ Limit personal information shared on social media\n" +
                "  ✅ Use privacy-focused search engines like DuckDuckGo or Brave\n" +
                "  ✅ Regularly review and revoke app permissions on your smartphone\n" +
                "  ✅ Check if your email was in a breach: haveibeenpwned.com\n" +
                "  ❌ Avoid oversharing your location, routine, or financial details online" },

            { "data",
                "Your personal data is valuable — protect it like your most important asset!\n" +
                "  • Use encrypted messaging apps like Signal for sensitive conversations\n" +
                "  • Enable full-disk encryption on your devices\n" +
                "  • Be cautious of 'free' apps — if it's free, your data is the product\n" +
                "  • Regularly delete accounts and apps you no longer use" },

            // ── Ransomware ───────────────────────────────────────────────────
            { "ransomware",
                "Ransomware is a dangerous type of malware that encrypts your files!\n" +
                "  Attackers then demand a ransom payment to restore your access.\n" +
                "  ⚠️ Even paying the ransom doesn't guarantee you'll get your files back.\n" +
                "  ✅ Back up your data regularly to an offline drive AND cloud storage\n" +
                "  ✅ Keep all software and OS updated to close security vulnerabilities\n" +
                "  ✅ Be extremely cautious with email attachments and unknown links\n" +
                "  ✅ Use reputable security software with ransomware protection" },

            // ── VPN & Public Wi-Fi ────────────────────────────────────────────
            { "vpn",
                "A VPN (Virtual Private Network) encrypts your internet connection.\n" +
                "  ✅ Always use a VPN on public Wi-Fi (cafés, airports, hotels)\n" +
                "  ✅ A VPN hides your browsing activity from your ISP and hackers\n" +
                "  ✅ Reputable VPNs: ProtonVPN, Mullvad, NordVPN, ExpressVPN\n" +
                "  ❌ Avoid free VPNs — many log and sell your data\n" +
                "  Note: A VPN improves privacy but is not a complete security solution" },

            { "public wi-fi",
                "Public Wi-Fi is a major security risk — here's how to stay safe:\n" +
                "  ⚠️ Hackers on the same network can intercept unencrypted traffic\n" +
                "  ✅ Use a VPN whenever connecting to public Wi-Fi\n" +
                "  ✅ Only visit HTTPS websites on public networks\n" +
                "  ❌ Never log into banking, email, or shopping on unsecured Wi-Fi\n" +
                "  ❌ Turn off automatic Wi-Fi connection on your devices" },

            // ── Online Banking ────────────────────────────────────────────────
            { "online banking",
                "Online banking security is critical — follow these best practices:\n" +
                "  ✅ Always access your bank via its official app or typed URL\n" +
                "  ✅ Enable 2FA / multi-factor authentication on your bank account\n" +
                "  ✅ Check your statements regularly for unauthorised transactions\n" +
                "  ❌ Never click email links claiming to be from your bank\n" +
                "  ❌ Never access banking on public Wi-Fi without a VPN\n" +
                "  ❌ Never share your PIN or OTP with anyone — even bank staff won't ask" },

            // ── Social Engineering ────────────────────────────────────────────
            { "social engineering",
                "Social engineering manipulates people psychologically rather than hacking systems.\n" +
                "  Common tactics:\n" +
                "  🎭 Impersonation — pretending to be IT support or a manager\n" +
                "  ⏰ Urgency — 'You must act NOW or face consequences!'\n" +
                "  🎁 Baiting — offering something enticing to get you to click or download\n" +
                "  ✅ Always verify unexpected requests through a trusted, separate channel\n" +
                "  ✅ No legitimate organisation will ever ask for your password" },

            // ── Exit Commands ─────────────────────────────────────────────────
            { "bye",
                "Thank you for chatting, {name}! Stay vigilant and stay safe online. 🛡️\n" +
                "Remember: Think Before You Click!" },

            { "goodbye",
                "Goodbye, {name}! Keep your digital life secure. " +
                "Come back anytime you have cybersecurity questions! 🛡️" },

            { "exit",
                "Exiting the Cybersecurity Awareness Bot. Stay cyber-safe, {name}! 🛡️" },

            { "quit",
                "Goodbye, {name}! Remember — your best security tool is your own awareness. 🛡️" }
        };

        /// <summary>
        /// Returns a response for the given user input.
        /// Returns null for empty input, "default" for unrecognised queries.
        /// Personalises exit messages with the user's name.
        /// </summary>
        public static string GetResponse(string input, string userName = "User")
        {
            if (string.IsNullOrWhiteSpace(input))
                return null; // signals empty/invalid input

            string trimmed = input.Trim();

            // Exact match (case-insensitive)
            if (ResponseMap.TryGetValue(trimmed, out string exactMatch))
                return exactMatch.Replace("{name}", userName);

            // Partial keyword matching — checks if input contains a known keyword
            string lower = trimmed.ToLower();
            foreach (var kvp in ResponseMap)
            {
                if (lower.Contains(kvp.Key.ToLower()))
                    return kvp.Value.Replace("{name}", userName);
            }

            return "default"; // signals no matching topic found
        }

        /// <summary>
        /// Returns true if the user input is an exit/quit command.
        /// </summary>
        public static bool IsExitCommand(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return false;
            string t = input.Trim().ToLower();
            return t == "bye" || t == "goodbye" || t == "exit" || t == "quit";
        }
    }
}
